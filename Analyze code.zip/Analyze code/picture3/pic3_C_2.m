clc,clear
% a=load("D:\paperdata\Data6\raw\index.txt");
b=load("D:\paperdata\Data7\neurogpstree_accuracy.txt");
c=load("D:\paperdata\Data7\sparsetrace_accuracy.txt");
d=load("D:\paperdata\Data7\sparsetrace-m_accuracy.txt");
e=load("D:\paperdata\Data7\svm_accuracy.txt");

accu1=sortrows(b,1);
accu2=sortrows(c,1);
accu3=sortrows(d,1);
accu4=sortrows(e,1);

accu1=accu1(:,2);
accu2=accu2(:,2);
accu3=accu3(:,2);
accu4=accu4(:,2);


interval=2;
interval1=interval+1;
line_width=0.7;
p1=1;
p2=1+3*interval;
p3=p2+interval1;
p4=p3+3*interval;
p5=p4+interval1;
p6=p5+3*interval;
p7=p6+interval1;
p8=p7+3*interval;
pos=[p1:interval:p2 p3:interval:p4 p5:interval:p6 p7:interval:p8];


colors = lines(4);  % 适合四组数据
x = zeros(100,1);


figure 
hold on

for i=1:4
    h(i)=boxchart(x+pos(i),accu1((i-1)*100+1:1:i*100,1),'BoxFaceColor',colors(1,:),'BoxWidth',line_width);
    h(i).MarkerStyle="none";
end
for i=1:4
    h(4+i)=boxchart(x+pos(4+i),accu2((i-1)*100+1:1:i*100,1),'BoxFaceColor',colors(2,:),'BoxWidth',line_width);
    h(4+i).MarkerStyle="none";
end
for i=1:4
    h(8+i)=boxchart(x+pos(8+i),accu3((i-1)*100+1:1:i*100,1),'BoxFaceColor',colors(3,:),'BoxWidth',line_width);
    h(8+i).MarkerStyle="none";
end
for i=1:4
    h(12+i)=boxchart(x+pos(12+i),accu4((i-1)*100+1:1:i*100,1),'BoxFaceColor',colors(4,:),'BoxWidth',line_width);
    h(12+i).MarkerStyle="none";
end



%%
%t检验




accu1=reshape(accu1,100,4);
accu2=reshape(accu2,100,4);
accu3=reshape(accu3,100,4);
accu4=reshape(accu4,100,4);
tt=[];
for i=1:3
    [h,pn]=ttest2(accu1(:,i),accu1(:,i+1));
    tt=[tt,pn];

end
tt1=[];
for i=1:3
    [h,pn]=ttest2(accu2(:,i),accu2(:,i+1));
    tt1=[tt1,pn];
end
tt2=[];
for i=1:3
    [h,pn]=ttest2(accu3(:,i),accu3(:,i+1));
    tt2=[tt2,pn];
end
tt3=[];
for i=1:3
    [h,pn]=ttest2(accu4(:,i),accu4(:,i+1));
    tt3=[tt3,pn];
end


tt=[ttest2(accu1(:,1),accu1(:,2)),ttest2(accu1(:,2),accu1(:,3)),ttest2(accu1(:,3),accu1(:,4));...
    ttest2(accu2(:,1),accu2(:,2)),ttest2(accu2(:,2),accu2(:,3)),ttest2(accu2(:,3),accu2(:,4));...
    ttest2(accu3(:,1),accu3(:,2)),ttest2(accu3(:,2),accu3(:,3)),ttest2(accu3(:,3),accu3(:,4));...
    ttest2(accu4(:,1),accu4(:,2)),ttest2(accu4(:,2),accu4(:,3)),ttest2(accu4(:,3),accu4(:,4))];