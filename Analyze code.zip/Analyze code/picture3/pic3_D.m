clc,clear
a=load("D:\paperdata\distance.txt");
b=a(:,5);
maxb=max(b);
minb=min(b);
step=(maxb-minb)/50;
number=zeros(50,1);
for i=1:length(b)
    for j=0:49
        if b(i)>=minb+(j)*step&&b(i)<minb+(j+1)*step
            number(j+1)=number(j+1)+1;
        end
    end
    if b(i)==minb+50*step
        number(50)=number(50)+1;
    end
end

number=number/sum(number);
number=number';
% for i=2:50
%     number(i)=number(i)+number(i-1);
% end
% number=[0,number];
x=minb:step:maxb;
y=zeros(50,0);
for i=1:50
    y(i)=(x(i)+x(i+1))/2;
end
sum(number(1:14))
plot(y,number,'LineWidth',1.5);
set(gca,'FontSize',10)
set(gca,'YLim',[0 1]);
yticks([0:0.25:1]);
xticks([0:5:20]);
set(gca,'Xticklabel',{'','','','',''});
set(gca,'Yticklabel',{'','','','',''});
% sset(gca,'Ytick',0:0.2:1);
% set(gca,'FontWeight','bold','Yticklabels',{'0','0.2','0.4','0.6','0.8','1'},'FontWeight','bold');