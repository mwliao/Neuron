clc,clear
a=load("D:\paperdata\testaccuracy1.txt");
a=a/50*100;
level1=a([1 5 9 13],:);
level2=a([2 6 10 14],:);
level3=a([3 7 11 15],:);
level4=a([4 8 12 16],:);


%t����
[h1,pn1] = ttest2(level1(2,:),level2(2,:));
[h2,pn2] = ttest2(level2(3,:),level3(3,:));
[h3,pn3] = ttest2(level3(4,:),level4(4,:));


% [p, tbl, stats] = kruskalwallis([group1, group2, group3], {'Group 1', 'Group 2', 'Group 3'});

% [h,p,ci,stats] = vartest2(l1,l2);
% if p < 0.05
%     [h1,p1,ci1] = ttest2(l1,l2,'Vartype','unequal');
% else
%     [h1,p1,ci1] = ttest2(l2,l3);
% end


interval=0.8;
interval1=interval+1;
line_width=0.7;
p1=1;
p2=1+3*interval;
p3=p2+interval1;
p4=p3+3*interval;
p5=p4+interval1;
p6=p5+3*interval;
p7=p6+interval1;
p8=p7+3*interval;
pos=[p1:interval:p2 p3:interval:p4 p5:interval:p6 p7:interval:p8];


colors = lines(4);  % �ʺ���������
x = zeros(size(level1,2),1);

figure 
hold on
for i=1:size(level1,1)
    h(i)=boxchart(x+pos(4*(i-1)+1),level1(i,:),'BoxFaceColor',colors(1,:),'BoxWidth',line_width);
end
for i=1:size(level2,1)
    h(4+i)=boxchart(x+pos(4*(i-1)+2),level2(i,:),'BoxFaceColor',colors(2,:),'BoxWidth',line_width);
end
for i=1:size(level3,1)
    h(8+i)=boxchart(x+pos(4*(i-1)+3),level3(i,:),'BoxFaceColor',colors(3,:),'BoxWidth',line_width);
end
for i=1:size(level4,1)
    h(12+i)=boxchart(x+pos(4*(i-1)+4),level4(i,:),'BoxFaceColor',colors(4,:),'BoxWidth',line_width);
end
% legend(h([1 5 9 13]),'','','','')
xlab=[(pos(1)+pos(4))/2,(pos(5)+pos(8))/2,(pos(9)+pos(12))/2,(pos(13)+pos(16))/2];
ylab=0:25:100;
xticks(xlab)
set(gca,'Xticklabel',{'','','',''});
yticks(ylab);
set(gca,'Yticklabel',{'','','','',''});

% h=boxplot(tmp,g,'colors','r','positions',position_4,'width',0.2,'symbol','');  %group_AΪ���ݣ�pre_group_AΪ���
% set(h,'LineWidth',1.5)
% set(gca,'XLim',[0 ceil((4-1)*1.5+1.1)]);                          %�޶�������ʾ����
% set(gca,'YLim',[40 100]);                         %�޶�������ʾ����
% set(gca,'ytick',[40:20:100]);
% set(gca,'FontSize',10)
% set(gca,'Xticklabel',{'L1','L2','L3','L4'},'FontWeight','bold','Yticklabel',{'0.4','0.6','0.8','1'},'FontWeight','bold');