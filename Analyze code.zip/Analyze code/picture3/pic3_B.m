clc,clear

fileFolder = fullfile('D:\paperdata\diffresult');
dirOutput = dir(fullfile(fileFolder,'*.txt'));
fileNames = {dirOutput.name};
a=[];
meanA=[0.0337821455315633,0.00809002861911516,0.000260009190481753,8.66225797686348e-05,0.412687525041988,0.0946151742834731,0.301793294301935,1292.04737315760,276.637898350143,9.48731994973093,2.99171849321690];
stdA=[0.0384674561776216,0.0145577606834159,0.000446529705748931,0.000282073815027157,0.714993752654174,0.105369312079346,0.210430144213733,1852.14366871854,716.654774208225,18.7787051563674,11.9014098891246];
para=[0.210370551427555;0.234225145100695;0.230348430516358;0.246148121880641;0.219340212148828;0.203122428836567;0.0595796562572662;0.171747899265769;0.206737653389003;0.207279759056318;0.228901605133935];
level=[-1.28 0.129 3.83 12.89 33.33];
judgeratio=[];
modifyratio=[];
convertratio=[];
tasknumber=0;
for k=1:1:length(fileNames)
    temp=cell2mat(fileNames(k));
    temp1=strsplit(temp,'_');
    if(length(temp1)==2)
        continue;
    end

    path=['D:\paperdata\diffresult\' cell2mat(fileNames(k))];
    tmp=load(path);
    if(size(tmp,1)<100)
        continue;
    end
    tasknumber=tasknumber+1;
    sign=tmp(:,17);
    index=tmp(:,2:12);
    A=(index-meanA)./stdA;
    score=A*para;
    number=zeros(4,1);
    number1=zeros(4,1);
    for i=1:size(score)
        if score(i)<level(2)
            number(1)=number(1)+1;
            if sign(i)==1
                number1(1)=number1(1)+1;
            end
        end
        if score(i)>=level(2)&&score(i)<level(3)
            number(2)=number(2)+1;
            if sign(i)==1
                number1(2)=number1(2)+1;
            end
        end
        if score(i)>=level(3)&&score(i)<level(4)
            number(3)=number(3)+1;
            if sign(i)==1
                number1(3)=number1(3)+1;
            end
        end
        if score(i)>=level(4)
            number(4)=number(4)+1;
            if sign(i)==1
                number1(4)=number1(4)+1;
            end
        end
    end
    judrat=number/sum(number);
    modrat=number1/sum(number1);

    number(find(number==0))=0.00001;
    number1(find(number1==0))=0.00001;
    conrat=number1./number;
%     if(length(conrat>1)>0)
%         1
%     end
%     tmp=[tmp(:,2:12),tmp(:,17)];
    judgeratio=[judgeratio;judrat'];
    modifyratio=[modifyratio;modrat'];
    convertratio=[convertratio;conrat'];
%     a=[a;tmp];
end





%%
% clc,clear
colors = lines(4);  % 适合四组数据
% colors = [0.2, 0.6, 0.8;   % 蓝色
%           0.9, 0.4, 0.2;   % 橙色
%           0.4, 0.8, 0.3;   % 绿色
%           0.7, 0.3, 0.7];  % 紫色
% group=repelem(1:4,size(judgeratio,1));
% boxchart(group, judgeratio(:),'BoxFaceColor',colors,'WhiskerLineColor',colors);
% judgeratio=judgeratio*100;
% h=boxchart(judgeratio*100); 

figure;
hold on;
for i = 1:4
    % 为每组绘制 boxchart 并设置相同的 BoxFaceColor 和 BoxEdgeColor
    tmp=repelem(i, size(judgeratio,1));
%     b = boxchart(tmp', judgeratio(:, i));
    b = boxchart(tmp', judgeratio(:, i),'BoxFaceColor',colors(i,:));
    b.MarkerStyle="none";
    % b.BoxMedianLineColor=colors(i,:);
%     b.JitterOutliers = 'on';
    % 设置中位数线颜色
    
end
plot(1:4,mean(judgeratio));
plot(1:4,mean(judgeratio),'*');
hold off;
xticks([])
xticks([0 1 2 3 4])
set(gca,'Xticklabel',{'','','','',''});
% yticks([])
yticks(0:0.25:1);
set(gca,'Yticklabel',{'','','','',''});
% set(h,'LineWidth',1.5)
% set(gca,'YLim',[0 100]);
% set(gca,'ytick',[0:20:100]);
% set(gca,'FontSize',10)
% set(gca,'Xticklabel',{'L1','L1','L3','L4'},'Yticklabel',{'0%','20%','40%','60%','80%','100%'});
%%
colors = lines(4);  % 适合四组数据
% colors = [0.2, 0.6, 0.8;   % 蓝色
%           0.9, 0.4, 0.2;   % 橙色
%           0.4, 0.8, 0.3;   % 绿色
%           0.7, 0.3, 0.7];  % 紫色
group=repelem(1:4,size(modifyratio,1));
% modifyratio=modifyratio*100;
% h=boxchart(judgeratio*100); 
figure;
hold on;
for i = 1:4
    % 为每组绘制 boxchart 并设置相同的 BoxFaceColor 和 BoxEdgeColor
    tmp=repelem(i, size(modifyratio,1));
%     b = boxchart(tmp', judgeratio(:, i));
    b = boxchart(tmp', modifyratio(:, i), 'BoxFaceColor', colors(i, :));
    b.MarkerStyle="none";
    % 设置中位数线颜色
    
end
plot(1:4,mean(modifyratio));
plot(1:4,mean(modifyratio),'*');
hold off;
xticks([])
xticks([0 1 2 3 4])
set(gca,'Xticklabel',{'','','','',''});
% yticks([])
yticks(0:25:100);
set(gca,'Yticklabel',{'','','','',''});

% mean(modifyratio)
% h=boxplot(modifyratio*100,'width',0.2,'symbol',''); 
% set(h,'LineWidth',1.5)
% set(gca,'YLim',[0 100]);
% set(gca,'ytick',[0:20:100]);
% set(gca,'FontSize',10)
% set(gca,'Xticklabel',{'L1','L1','L3','L4'},'Yticklabel',{'0%','20%','40%','60%','80%','100%'});

%%
colors = lines(4);  % 适合四组数据
% colors = [0.2, 0.6, 0.8;   % 蓝色
%           0.9, 0.4, 0.2;   % 橙色
%           0.4, 0.8, 0.3;   % 绿色
%           0.7, 0.3, 0.7];  % 紫色
group=repelem(1:4,size(convertratio,1));
% convertratio=convertratio*100;
% h=boxchart(judgeratio*100); 
figure;
hold on;
for i = 1:4
    % 为每组绘制 boxchart 并设置相同的 BoxFaceColor 和 BoxEdgeColor
    tmp=repelem(i, size(convertratio,1));
%     b = boxchart(tmp', judgeratio(:, i));
    b = boxchart(tmp', convertratio(:, i), 'BoxFaceColor', colors(i, :));
    b.MarkerStyle="none";
    % 设置中位数线颜色
    
end
plot(1:4,mean(convertratio));
plot(1:4,mean(convertratio),'*');
hold off;
xticks([])
xticks([0 1 2 3 4])
set(gca,'Xticklabel',{'','','','',''});
% yticks([])
yticks(0:25:100);
set(gca,'Yticklabel',{'','','','',''});

% mean(convertratio)
% h=boxplot(convertratio*100,'width',0.2,'symbol',''); 
% set(h,'LineWidth',1.5)
% set(gca,'YLim',[0 100]);
% set(gca,'ytick',[0:20:100]);
% set(gca,'FontSize',10)
% set(gca,'Xticklabel',{'L1','L1','L3','L4'},'Yticklabel',{'0%','20%','40%','60%','80%','100%'});

% number=number/sum(number);
% bar([0.1 0.2 0.3 0.4],number*100,0.4)
% set(gca,'XTick',[])