clc,clear

fileFolder = fullfile('D:\paperdata\diffresult');
dirOutput = dir(fullfile(fileFolder,'*.txt'));
fileNames = {dirOutput.name};
a=[];
meanA=[0.0337821455315633,0.00809002861911516,0.000260009190481753,8.66225797686348e-05,0.412687525041988,0.0946151742834731,0.301793294301935,1292.04737315760,276.637898350143,9.48731994973093,2.99171849321690];
stdA=[0.0384674561776216,0.0145577606834159,0.000446529705748931,0.000282073815027157,0.714993752654174,0.105369312079346,0.210430144213733,1852.14366871854,716.654774208225,18.7787051563674,11.9014098891246];
para=[0.210370551427555;0.234225145100695;0.230348430516358;0.246148121880641;0.219340212148828;0.203122428836567;0.0595796562572662;0.171747899265769;0.206737653389003;0.207279759056318;0.228901605133935];
level=[-1.28 0.129 3.83 12.89 33.33];
judgeratio=[];
modifyratio=[];
convertratio=[];
tasknumber=0;
diffdata=[];
for k=1:1:length(fileNames)
    temp=cell2mat(fileNames(k));
    temp1=strsplit(temp,'_');
    if(length(temp1)==2)
        continue;
    end
    
    path=['D:\paperdata\diffresult\' cell2mat(fileNames(k))];
    tmp=load(path);
    
    if(size(tmp,1)<100)
        continue;
    end
    tmp=tmp(:,2:12);
    A=(tmp-meanA)./stdA;
    B=A*para;
    diffdata=[diffdata;A(B>level(3),:)];
end
% hFig = figure;
% hAx = axes;
% go=bar(number);
% go.FaceColor=[0.4627    0.7176    0.6980];
% set(gca,'FontSize',10,'FontWeight','bold')
% hAx.XTickLabel={'Fiber density','Target fiber density','Keypoint density','Target keypoint density','Signal density','Projection signal density','Weak signal ratio','Fiber length','Target fiber length','Keypoint number','Target keypoint number'};
% xtickangle(-45)
%%

colors = lines(11);  % �ʺ���������
% group=repelem(1:11,size(diffdata,1));
% boxchart(group, diffdata(:),'BoxFaceColor',colors(5,:),'WhiskerLineColor',colors(5,:));
x = zeros(size(diffdata,1),1);
pos=1:11;
figure(1)
hold on
for i=1:11
    b=boxchart(x+pos(i),diffdata(:,i),'BoxFaceColor',colors(i,:));
    b.MarkerStyle="none";
end

% h=boxplot([diffdata(:,1),diffdata(:,2),diffdata(:,3),diffdata(:,4),diffdata(:,5),diffdata(:,6),diffdata(:,7),diffdata(:,8),diffdata(:,9),diffdata(:,10),diffdata(:,11)],'width',0.2,'symbol',''); 
% set(h,'LineWidth',1.5)
set(gca,'XLim',[0 12]);                          %�޶�������ʾ����
set(gca,'YLim',[-2 18]);                         %�޶�������ʾ����
set(gca,'ytick',[-2:4:18]);
set(gca,'xtick',[1:1:11]);
% set(gca,'Xticklabel','FontWeight','bold');
% set(gca,'FontSize',10,'FontWeight','bold')
% set(gca,'FontSize',10,'FontName','Time New Roman')
% hAx.XTickLabel={'Fiber density','Target fiber density','Keypoint density','Target keypoint density','Signal density','Projection signal density','Weak signal ratio','Fiber length','Target fiber length','Keypoint number','Target keypoint number'};
set(gca,'Yticklabel',{'','','','','',''});
set(gca,'Xticklabel',{'','','','','','','','','','',''});

% xtickangle(-60)
% set(gca,'Xticklabel',{'1#','2#','3#','4#','5#','6#','7#','8#','9#','10#'},'FontWeight','bold','Yticklabel',{'0%','20%','40%','60%','80%','100%'},'FontWeight','bold');
% set(gca,'Xticklabel', ['Fiber density','Target fiber density','Keypoint density','Target keypoint density','Signal density','Projection signal density','Weak signal ratio','Fiber length','Target fiber length','Keypoint number','Target keypoint number'])  %gca ����ľ��

% name=['Fiber density','Target fiber density','Keypoint density','Target keypoint density','Signal density','Projection signal density','Weak signal ratio','Fiber length','Target fiber length','Keypoint number','Target keypoint number'];
