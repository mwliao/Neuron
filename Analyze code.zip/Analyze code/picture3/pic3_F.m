clc,clear
fileFolder = fullfile('D:\paperdata\diffdata');
dirOutput = dir(fullfile(fileFolder,'*.txt'));
fileNames = {dirOutput.name};
diffdata=[];
for fl=1:1:length(fileNames)
    filepath=['D:\paperdata\diffdata\' cell2mat(fileNames(fl))];
    a=load(filepath);
    for i=1:size(a,1)
        if((a(i,13)+1.76)/(9.75+1.76)>0.6)
            diffdata=[diffdata;a(i,:)];
        end
    end
end
a=diffdata(:,2:12);

meanA=mean(a);
stdA=std(a);
A=(a-meanA)./stdA;

% h=boxplot(A,'width',0.2,'symbol',''); 
% set(h,'LineWidth',1.5)
% set(gca,'YLim',[-5 5]);
% % set(gca,'ytick',[0:20:100]);
% set(gca,'FontSize',10)
% set(gca,'Xticklabel',{'L1','L1','L3','L4'},'FontWeight','bold','FontWeight','bold');


CMP=corrMatPlot(a,'Labels',{'','','','','','','','','','',''});
CMP=CMP.draw()
% {'Fiber density','Target fiber density','Keypoint density','Target keypoint density','Signal density','Projection signal density','Weak signal ratio','Fiber length','Target fiber length','Keypoint number','Target keypoint number'}
% set(gca,'FontSize',10,'FontWeight','bold')
