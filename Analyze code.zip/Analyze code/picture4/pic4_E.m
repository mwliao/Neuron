clc,clear
taskaccu=0.9:9*0.001:0.999;
useaccu=0.83:0.02:0.97;
[X,Y]=meshgrid(taskaccu,useaccu);

F1=load("D:\paperdata\data\accuracy_changgui.txt");
tmp=zeros(size(X));
for i=1:size(X,1)
    for j=1:size(X,2)
        tmp(i,j)=mean(F1(i+(j-1)*size(X,1),:));
    end
end
% surf(X,Y,tmp);

F1=load("D:\paperdata\data\accuracy_fen.txt");
tmp1=zeros(size(X));
for i=1:size(X,1)
    for j=1:size(X,2)
        tmp1(i,j)=mean(F1(i+(j-1)*size(X,1),:));
    end
end

F1=load("D:\paperdata\data\accuracy_gai.txt");
tmp2=zeros(size(X));
for i=1:size(X,1)
    for j=1:size(X,2)
        tmp2(i,j)=mean(F1(i+(j-1)*size(X,1),:));
    end
end


cha1=tmp2-tmp1;
cha2=tmp1-tmp;

% findex=6;
% Y1=cha2(findex,:);
% findex1=find(taskaccu==0.954);
% Y2=cha2(:,findex1);
% plot(taskaccu,Y1);
% hold on
% plot(useaccu,Y2);
% legend('Image block accuracy','Worker accuracy')
surf(X,Y,cha2);
% mean(mean(cha1))
% surf(X,Y,cha1);
