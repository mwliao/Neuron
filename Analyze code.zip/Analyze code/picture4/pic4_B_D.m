
%% ʵ�ʷ�����ҵʱworker׼ȷ�ȡ�������Ԥ��׼ȷ��֮��Ĺ�ϵ
clc,clear
useracc=load("D:\Journal_Article\pattern\Data\picture4\personal_accuracy_B.txt");
prethre=load("D:\Journal_Article\pattern\Data\picture4\blockaccuracy_B.txt");
allnumpl=load("D:\Journal_Article\pattern\Data\picture4\personal_number_B.txt");
[X,Y]=meshgrid(useracc,prethre);
surf(X,Y,allnumpl);

%% ģ�����������

x=0.99:0.0001*3:0.9999;
neuronlg=load("D:\Journal_Article\pattern\Data\picture4\Simulation-accuracy\neuron.txt");
A=load("D:\Journal_Article\pattern\Data\picture4\Simulation-accuracy\accuracy.txt");
B=A(:,[1:4 7:8 11:12 15:16 19:20]);
C=B(:,3:end);
D=mean(C(:,1:2:end)')'./C(:,2);
step=length(D)/56;
M=[];
for i=1:1:step
    M=[M,D((i-1)*56+1:1:(i)*56,1)];
end
plot(x,mean(M),'*')
y=mean(M);
[b,bint,r,rint,stats] = regress(y',[x',ones(length(x),1)]);
xishu=polyfit(x,mean(M),1);
nihe=x*xishu(1)+xishu(2);
hold on
plot(x,nihe)
legend('Simulation value','Fit curve')


%% ʵ�ʷ�����ҵʱworker׼ȷ�ȡ���������Ԫ׼ȷ��֮��Ĺ�ϵ
clc,clear
useracc=load("D:\Journal_Article\pattern\Data\picture4\personal_accuracy_C.txt");
realaccu=load("D:\Journal_Article\pattern\Data\picture4\neuron_accuracy_C.txt");
allnumpl=load("D:\Journal_Article\pattern\Data\picture4\personal_number_C.txt");
[X,Y]=meshgrid(useracc,realaccu);
surf(X,Y,allnumpl);