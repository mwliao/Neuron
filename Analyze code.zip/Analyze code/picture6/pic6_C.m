clc,clear
ouraccuracy=0.98;
ourrecall=0.97;

ourspeed=1.0;
mouselight=[85.9 93.7 96.5 97.9 98.7 99.2 99.2 100]/100;
gapr=[0.806 0.830 0.859 0.966 1];
mouseligthspeed=[29.75 27.2 21.25 25.44 13.66666667 13.85714286 15.33333333 7.5 4.125 16.25 28.70588235 16.79272727 18.28571429 40 43.11111111...
    13.30542857 27.69230769 30.4 33.84615385 57.16666667 19.41685393 22.4 41.2 14.2172 32.66666667 35.5994 39.6 35.78947368 24.18181818 12.78338462 18.20722892 15.65217391 36.62071429];
mouseligthspeed=mouseligthspeed/10;
gaprspeed=[2.18 4.89];
gaprsp=[1/(1/2.18+1/4.89) 1/(1/2.18+2*1/4.89) 1/(1/2.18+3*1/4.89) 1/(1/2.18+4*1/4.89)];
mouselightsp=[mean(mouseligthspeed),mean(mouseligthspeed)/2,mean(mouseligthspeed)/3,mean(mouseligthspeed)/4 ...
    mean(mouseligthspeed)/5,mean(mouseligthspeed)/6,mean(mouseligthspeed)/7,mean(mouseligthspeed)/8];
h(1)=plot(ouraccuracy,ourspeed,'*','color','red','linewidth',2);
hold on
h(2)=plot(ourrecall,ourspeed,'*','color','blue','linewidth',2);

h(3)=plot(gapr(1:4),gaprsp,'linewidth',2);
h(4)=plot(mouselight,mouselightsp,'linewidth',2);

h(5)=plot([0.98 0.98],[0 3],'--');
h(6)=plot([0.8 1],[1.0 1.0],'--');

h(7)=plot([ourrecall ourrecall],[0 3],'--');
h(8)=plot([0.8 1],[1.0 1.0],'--');
legend(h([1 2 3 4]),'CrowdTree(F1)','CrowdTree(recall)','Gapr(F1)','Mouselight(recall)')
xlab=0.8:0.05:1;
ylab=0:1:3;
xticks(xlab)
set(gca,'Xticklabel',{'','','','',''});
yticks(ylab);
set(gca,'Yticklabel',{'','','',''});

% 
%%
% xticklabels({'240939','240083','240081','240084','240082','233927','233878','233877'});
% panduan=[4.28 5.01 4.37 4.02 4.37 5.29 4.91 4.83]'*10;
% xiuzheng=[1.86 2.26 1.69 2.4 2.05 2.10 2.26 1.73]'*10;
% onepanduan=[9.56 11.06 10.2 9.04 9.94 12.46 11.94 12.2]'*10./panduan;
% onexiuzheng=[1.94 2.32 1.80 2.55 2.22 2.21 2.40 1.83]'*10./xiuzheng;
% all1=[onepanduan,onexiuzheng];
% color_matrix = [0.8,0,0
%                 0,0,0.8];
% h2 = barh(all1(:,1:2),1);
% set(h2(1),'facecolor',color_matrix(1,:))
% set(h2(2),'facecolor',color_matrix(2,:))
% xticks([0 1 2 3])
% set(gca,'YTickLabel',{'240939','240083','240081','240084','240082','233927','233878','233877'});
% legend('Data judging','Data proofreading')

