clc,clear
a=load('D:/paperdata/tasktime.txt');
a=a/3600;
pic=[];
g=[];
pic=[pic;a(:,1:4)];
g=[g,1*ones(size(a(:,1:4),1),1)'];
n1=size(a(:,1:4),1);

pic=[pic;a(:,5:8)];
g=[g,2*ones(size(a(:,5:8),1),1)'];
chosenumber=2;
n2=size(a(:,5:8),1);
x=zeros(n1+n2,1);

A1=[pic(:,1)];
A2=[pic(:,2)];
A3=[pic(:,3)];
A4=[pic(:,4)];
mean(pic)

% h=boxplot(A1,g,'colors','b','positions',position_1,'width',0.2,'symbol','');  %group_A为数据，pre_group_A为组号
% set(h,'LineWidth',1.5)
% hold on
% 
% h=boxplot(A2,g,'colors','g','positions',position_3,'width',0.2,'symbol',''); 
% set(h,'LineWidth',1.5)
% 
% h=boxplot(A3,g,'colors','k','positions',position_2,'width',0.2,'symbol','');
% set(h,'LineWidth',1.5)
% 
% h=boxplot(A4,g,'colors','r','positions',position_2,'width',0.2,'symbol','');

figure(1)
hold on
colors = lines(4);  % 适合四组数据
position_1 = 0.2:1.5:(chosenumber-1)*1.5+0.2; 
position_2 = 0.5:1.5:(chosenumber-1)*1.5+0.5; 
position_3 = 0.8:1.5:(chosenumber-1)*1.5+0.8; 
position_4 = 1.1:1.5:(chosenumber-1)*1.5+1.1; 
b=boxchart(x(1:n1,1)+position_1(1), A1(1:n1,1),'BoxFaceColor',colors(1,:),'WhiskerLineColor',colors(1,:),'BoxWidth',0.2);
% b.MarkerStyle="none";
b=boxchart(x(n1+1:n2+n1,1)+position_1(2), A1(n1+1:n2+n1,1),'BoxFaceColor',colors(1,:),'WhiskerLineColor',colors(1,:),'BoxWidth',0.2);
% b.MarkerStyle="none";
b=boxchart(x(1:n1,1)+position_2(1), A2(1:n1,1),'BoxFaceColor',colors(2,:),'WhiskerLineColor',colors(2,:),'BoxWidth',0.2);
% b.MarkerStyle="none";
b=boxchart(x(n1+1:n2+n1,1)+position_2(2), A2(n1+1:n2+n1,1),'BoxFaceColor',colors(2,:),'WhiskerLineColor',colors(2,:),'BoxWidth',0.2);
% b.MarkerStyle="none";
b=boxchart(x(1:n1,1)+position_3(1), A3(1:n1,1),'BoxFaceColor',colors(3,:),'WhiskerLineColor',colors(3,:),'BoxWidth',0.2);
% b.MarkerStyle="none";
b=boxchart(x(n1+1:n2+n1,1)+position_3(2), A3(n1+1:n2+n1,1),'BoxFaceColor',colors(3,:),'WhiskerLineColor',colors(3,:),'BoxWidth',0.2);
% b.MarkerStyle="none";
b=boxchart(x(1:n1,1)+position_4(1), A4(1:n1,1),'BoxFaceColor',colors(4,:),'WhiskerLineColor',colors(4,:),'BoxWidth',0.2);
% b.MarkerStyle="none";
b=boxchart(x(n1+1:n2+n1,1)+position_4(2), A4(n1+1:n2+n1,1),'BoxFaceColor',colors(4,:),'WhiskerLineColor',colors(4,:),'BoxWidth',0.2);
% b.MarkerStyle="none";

box on

% set(h,'LineWidth',1.5)
% set(gca,'XLim',[0 ceil((chosenumber-1)*1.5+1.1)]);                          %限定横轴显示长度
% set(gca,'YLim',[0 250]);                         %限定纵轴显示长度
set(gca,'ytick',[0:100:500]);
set(gca,'Yticklabel',{'','','','','',''});
xticks([])
% set(gca,'FontSize',12)
% set(gca,'FontWeight','bold')
% ax = gca;
% xticks = get(ax,'XTickLabel');

% set(gca,'Xticklabel',{'1#','2#','3#','4#','5#','6#','7#','8#','9#','10#'},'FontWeight','bold','Yticklabel',{'0%','20%','40%','60%','80%','100%'},'FontWeight','bold');