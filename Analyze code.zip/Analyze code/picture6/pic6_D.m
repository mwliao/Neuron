% a=load('D:/paperdata/singleswclen.txt');
clc,clear
a=load("D:\neuron\allswc\allswc\swclen.txt");
histogram(a);

xticks(0:50:400)
yticks(0:200:800);
% set(gca,'FontSize',10)
set(gca,'Xticklabel',{'','','','','','','','',''});
set(gca,'Yticklabel',{'','','',''});
mean(a)

% set(gca,'FontSize',12)
% set(gca,'FontWeight','bold')