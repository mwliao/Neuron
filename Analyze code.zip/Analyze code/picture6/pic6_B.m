clc,clear
a=[0.99721 0.984679 1 0.993231 0.884544 0.996325 1 0.962236 0.995168 0.968426 0.998979 0.959624 0.998657 0.996181 0.999355];
b=[0.81209 0.613161 0.790261 0.135621 0.994972 0.958158 0.95876 0.992154 0.978105 0.863564 0.906303 0.878607 0.893761 0.573631 0.737302];

arecall=[0.994436 0.976058 1 0.986554 0.792988 0.992676 1 0.92722 0.99195 0.938785 0.997961 0.925713 0.997317 0.992391 0.998711];

c=[95.12397132 95.67988762 98.40381124 86.90979446 93.91142444 82.27561257 85.75754363 97.15018354 99.2154888 95.55730775 96.48030108 95.25251454 94.00418759 99.60641921 95.21872225 95.34527769 93.95648083 93.99756165 98.66156028 99.25458184 98.32429997 98.69402738  93.24087939 86.12329548 86.38899564 92.60015107 92.62002889 84.98363393];
c=c/100;
% mm=a;
% gg=ones(1,length(a));
% mm=[mm,b];
% gg=[gg,2*ones(1,length(b))];
% 
% mm=[mm,arecall];
% gg=[gg,3*ones(1,length(arecall))];
% 
% mm=[mm,c];
% gg=[gg,4*ones(1,length(c))];
position_1 = [1 2.5 4 5.5]; 
% h=boxplot(mm,gg,'colors','b','positions',position_1,'width',0.2,'symbol','');  %group_A为数据，pre_group_A为组号
colors = lines(4);  % 适合四组数据
figure
hold on

uu=boxchart(zeros(length(a),1)+position_1(1),a,'BoxFaceColor',colors(1,:));
% uu.MarkerStyle="none";
uu=boxchart(zeros(length(b),1)+position_1(2),b,'BoxFaceColor',colors(2,:));
% uu.MarkerStyle="none";
uu=boxchart(zeros(length(arecall),1)+position_1(3),arecall,'BoxFaceColor',colors(3,:));
% uu.MarkerStyle="none";
uu=boxchart(zeros(length(c),1)+position_1(4),c,'BoxFaceColor',colors(4,:));
% uu.MarkerStyle="none";

xlab=position_1;
ylab=0:0.25:1;
xticks(xlab)
set(gca,'Xticklabel',{'','','',''});
yticks(ylab);
set(gca,'Yticklabel',{'','','','',''});

box on
% set(h,'LineWidth',1.5)
% set(gca,'ytick',[0:0.2:1]);
% hold on; % 保持当前图形，以便在其上绘制数据点
% % boxplot(y, 'orientation', 'vertical');
% scatter(ones(length(a),1), a,10, 'filled');
% scatter(1.5*ones(length(b),1), b,10, 'filled');
% scatter(2.5*ones(length(arecall),1), arecall,10, 'filled');
% scatter(3*ones(length(c),1), c,10, 'filled');
% % set(gca,'Xticklabel',{'CrowdTree','Gapr','Mouselight'})
% xticks([1 1.5 2.5 3])
% % set(gca,'FontSize',10)
% set(gca,'Xticklabel',{'','','',''});


