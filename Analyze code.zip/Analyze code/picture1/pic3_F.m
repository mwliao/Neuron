a=load("D:\Journal_Article\pattern\Data\picture1\neuron_spatial_distribution_map.txt");
col=[0.5,0.5,0.5;0,1,1;0,0,1;1,0,0];
c=[100000,100000,100000,0,0,0];
for i=1:1:size(a,1)
     if a(i,6)>4
        a(i,6)=4;
     end
     if a(i,6)<1
        a(i,6)=1;
     end
     tp=col(a(i,6),:);
     c(1)=min(c(1),a(i,2));
     c(2)=min(c(2),a(i,3));
     c(3)=min(c(3),a(i,4));
     c(4)=max(c(4),a(i,2));
     c(5)=max(c(5),a(i,3));
     c(6)=max(c(6),a(i,4));
     plot3(a(i,2),a(i,3),a(i,4),'o','Color',tp);
     hold on
     if i>1
         x=[a(i,2) a(a(i,5),2)];
         y=[a(i,3) a(a(i,5),3)];
         z=[a(i,4) a(a(i,5),4)];
         plot3(x,y,z,'Color',[0.5 0.5 0.5]);
     end
     hold on
end
set(gcf,'color','w')
pt1=[c(1),c(2),c(3)];
pt2=[c(1),c(5),c(3)];
pt3=[c(4),c(2),c(3)];
pt4=[c(4),c(5),c(3)];

% plot3([pt1(1) pt2(1)],[pt1(2) pt2(2)],[pt1(3) pt2(3)]);
% plot3([pt1(1) pt3(1)],[pt1(2) pt3(2)],[pt1(3) pt3(3)]);
% plot3([pt4(1) pt2(1)],[pt2(2) pt4(2)],[pt4(3) pt2(3)]);
% plot3([pt4(1) pt3(1)],[pt4(2) pt3(2)],[pt4(3) pt3(3)]);

pt5=[c(1),c(2),c(6)];
pt6=[c(1),c(5),c(6)];
pt7=[c(4),c(2),c(6)];
pt8=[c(4),c(5),c(6)];

% plot3([pt5(1) pt6(1)],[pt5(2) pt6(2)],[pt5(3) pt6(3)]);
% plot3([pt5(1) pt7(1)],[pt5(2) pt7(2)],[pt5(3) pt7(3)]);
% plot3([pt6(1) pt8(1)],[pt6(2) pt8(2)],[pt6(3) pt8(3)]);
% plot3([pt7(1) pt8(1)],[pt7(2) pt8(2)],[pt7(3) pt8(3)]);
% 
% plot3([pt1(1) pt5(1)],[pt1(2) pt5(2)],[pt1(3) pt5(3)]);
% plot3([pt2(1) pt6(1)],[pt2(2) pt6(2)],[pt2(3) pt6(3)]);
% plot3([pt3(1) pt7(1)],[pt3(2) pt7(2)],[pt3(3) pt7(3)]);
% plot3([pt4(1) pt8(1)],[pt4(2) pt8(2)],[pt4(3) pt8(3)]);

set(gca,'xtick',[],'ytick',[],'ztick',[],'xcolor','w','ycolor','w','zcolor','w')