clc,clear
% datano={'220888', '230252' ,'230255' ,'230256', '230329'};
blocknumber=load("D:\paper1_picture\Data\picture2\block_number_L0.txt");
rawblock=load("D:\paper1_picture\Data\picture2\block_number_raw.txt");

problock=[0.182 0.019 0.059 0.042 0.192];
L0datasize=load("D:\paper1_picture\Data\picture2\size_L0.txt");
rawdatasize=load("D:\paper1_picture\Data\picture2\size_raw.txt");
color=lines(8);
figure(1)
temp=[rawblock;blocknumber]';
bar(temp)
% b=bar(1:5,rawblock);
% b.BarWidth=0.3;
% b.FaceColor=color(3,:);
% hold on
% b=bar(1.5:1:5.5,blocknumber);
% b.BarWidth=0.3;
% b.FaceColor=color(4,:);
% set(gca,'xticklabel',datano);
xticks([])
legend('Raw data','L0 data')
figure(2)
temp=[rawdatasize;L0datasize]';
bar(temp);
% set(gca,'xticklabel',datano);
legend('Raw data','L0 data')
xticks([])