clc,clear
% A=load("H:\Adaptivetest\avetime.txt")*100;
A=load("D:\paperdata\Adaptivetest\averagenumber.txt")*100;
% A=load("F:\Reserachdata\JournalPaper\Data\self-adaptiontrace\Adaptivetest\F.txt")*100;
x=[];
y=[];
h1=[];
C=[];
mycolor=[[125,175,044];[214,084,22];[79,190,236];[237,178,26];[0,113,196];[118,045,134]]/255;
saveb=[];
for i=1:6
    b=[];
    b=[A((i-1)*3+1,:),A((i-1)*3+2,:),A((i-1)*3+3,:);];
    C=[C;b];
    [val,index]=max(b);
    x=[x,index];
    y=[y,val];
   h1=[h1 plot(b,'LineWidth',1)];
   saveb=[saveb;b];
   hold on
end
axis([0,13 0 100]);
wordsize=10;
set(gca,'XTick',1:1:12);
plot(x,y,'*','LineWidth',3)
% set(gca,'XTickLabel',{'','','','','','','','','','','',''});
box off
set(gca,'FontSize',wordsize)
set(gca,'XTickLabel',{'NeuroGPS-Tree','SparseTracer','SparseTracer-m','Svm',...
    'NeuroGPS-Tree','SparseTracer','SparseTracer-m','Svm',...
    'NeuroGPS-Tree','SparseTracer','SparseTracer-m','Svm'});
xtickangle(-45)
% 
y=0:2:100;
x1=ones(length(y),1)*1;
x2=ones(length(y),1)*4;
x3=ones(length(y),1)*5;
x4=ones(length(y),1)*8;
x5=ones(length(y),1)*9;
x6=ones(length(y),1)*12;
plot(x1,y,'--','color','g');
plot(x2,y,'--','color','g');
plot(x3,y,'--','color','k');
plot(x4,y,'--','color','k');
plot(x5,y,'--','color','b');
plot(x6,y,'--','color','b');
text(1.5,90,'Enchance','FontSize',wordsize)
text(6.1,90,'Raw','FontSize',wordsize)
text(9.8,90,'Denoise','FontSize',wordsize)
lgd=legend(h1(1:6),'DN-Dense signal','DN-Normal signal',...
'DN-Weak signal','UN-Dense signal',...
'UN-Normal signal','UN-Weak signal');
title(lgd,['DN(Discrete noise)',newline,'UN(Uniform noise)'])



mm=[];
y=[max(C')]
% y=[C(1,12),C(2,2),C(3,2),C(4,2),C(5,2),C(6,3)];
for i=1:12
    a=C(:,i);
    mm=[mm,y'-a];
%     mm=[mm,1-y'./a];
end
[value,ind]=min(sum(mm)/6)
figure(2)
plot(1:6,mm(:,ind),'LineWidth',2)
hold on;
plot(1:6,mm(:,ind),'*')
for i = 1:6
    text(i, mm(i,ind), sprintf('%.1f', mm(i,ind)), 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
end
% set(gca,'XTick',1:1:6);
% set(gca,'XTickLabel',{'Dense signal','Normal signal',...
% 'Weak signal','Dense signal',...
% 'Normal signal','Weak signal'});
set(gca,'FontSize',wordsize)
axis([0,7 0 8]);
set(gca,'XTickLabel',{'','','','','','','',''});
box off
% xtickangle(-45)
% hold on
% y=0:1:8;
% x1=ones(length(y),1)*1;
% x2=ones(length(y),1)*3;
% x3=ones(length(y),1)*4;
% x4=ones(length(y),1)*6;
% 
% plot(x1,y,'--','color','g');
% plot(x2,y,'--','color','g');
% plot(x3,y,'--','color','k');
% plot(x4,y,'--','color','k');
% 
% text(1.2,7.5,'Discrete noise','FontSize',wordsize)
% text(4.2,7.5,'Uniform noise','FontSize',wordsize)

% text(6,1,'DN(Discrete noise)','color','r')
% text(6,1.5,'UN(Uniform noise)','color','r')

