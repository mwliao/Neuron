from model import *
from data import *
import os
import skimage
from PIL import Image
import keras_metrics as km
from keras.utils import to_categorical
from keras.preprocessing.image import ImageDataGenerator
from keras.callbacks import ModelCheckpoint, LearningRateScheduler, TensorBoard, EarlyStopping, ReduceLROnPlateau
from keras.models import load_model
from keras.optimizers import Adam
import tensorflow as tf
import argparse
import numpy as np
import cv2
import time
import math
from skimage import morphology
import random



# def freeze_session(model_path=None, clear_devices=True):
#     tf.compat.v1.reset_default_graph()
#     session = tf.compat.v1.keras.backend.get_session()
#     graph = session.graph
#     with graph.as_default():
#         model = tf.keras.models.load_model(model_path)
#         output_names = [out.op.name for out in model.outputs]
#         print("output_names", output_names)
#         input_names = [innode.op.name for innode in model.inputs]
#         print("input_names", input_names)
#         input_graph_def = graph.as_graph_def()
#         for node in input_graph_def.node:
#             print('node:', node.name)
#         print("len node1", len(input_graph_def.node))
#         if clear_devices:
#             for node in input_graph_def.node:
#                 node.device = ""
#         frozen_graph = tf.compat.v1.graph_util.convert_variables_to_constants(session, input_graph_def,
#                                                                               output_names)
#
#         outgraph = tf.compat.v1.graph_util.remove_training_nodes(frozen_graph)  # 去掉与推理无关的内容
#         print("##################################################################")
#         for node in outgraph.node:
#             print('node:', node.name)
#         print("length of  node", len(outgraph.node))
#         tf.io.write_graph(frozen_graph, "./models", "lenet5_h5.pb", as_text=False)
#         return outgraph
#
#
# def main():
#     freeze_session("unet_limo_20230721.hdf5", True)
#
#
# main()



# os.environ["CUDA_VISIBLE_DEVICES"] = "0" #字符串所对应环境的映像对象
# config = tf.compat.v1.ConfigProto()
# config.gpu_options.per_process_gpu_memory_fraction = 0.8  #占用50%显存
# session = tf.compat.v1.Session(config=config)

# data_gen_args = dict(rotation_range=0.2,
#                     width_shift_range=0.05,
#                     height_shift_range=0.05,
#                     shear_range=0.05,
#                     zoom_range=0.05,
#                     horizontal_flip=True,
#                     fill_mode='nearest')
# #train
# myGene = trainGenerator(1,'data/18749/train','image','label',data_gen_args,save_to_dir = None,target_size=(256,256))
#
# #model = unet(input_size = (256,256,1))
# model=load_model('unet_limo_20230721.hdf5')
# model_checkpoint = ModelCheckpoint('unet_limo_20230721.hdf5', monitor='loss',verbose=1, save_best_only=True) #保存模型
# print(tf.test.is_gpu_available())
# model.fit_generator(myGene,steps_per_epoch=101,epochs=300,callbacks=[model_checkpoint,TensorBoard(log_dir='./log')])

# #test
# testGene = testGenerator("X:/liaomingwei/imagetest/8bitsignal",target_size = (256,256))
# model = unet()
# model.load_weights("unet_limo_20230721.hdf5")
# results = model.predict_generator(testGene,4160,verbose=1)
# saveResult("data/18749/test",results)

# predict
# testGene = testGenerator("X:/unet/8bitimage/nosignal")
# model = unet()
# model.load_weights("unet_limo_20230721.hdf5")
# results = model.predict_generator(testGene,233,verbose=1)
# saveResult("X:/unet/8bitimage/seg_nosignal",results)

# img_dir = r'X:\liaomingwei\imagetest\signal\512\16bit'
# img_names = glob.glob(os.path.join(img_dir,'*.tif'))
# img_out = r'X:\liaomingwei\imagetest\signal\512\16bit\seg1'
# model = unet()
# model.load_weights("unet_limo_20230721.hdf5")
#
# img_neuron = {'signal':[]}
# num=0
# for name in img_names:
#     print(name)
#     img = io.imread(name)
#     basename = os.path.basename(name).split('.')[0]
#     isadd=0
#     for y in range(math.ceil(img.shape[0]/256)-1):
#         for x in range(math.ceil(img.shape[1]/256)-1):
#             xbg=x*256
#             ybg=y*256
#             xend=min(img.shape[1]-1,(x+1)*256)
#             yend=min(img.shape[0]-1,(y+1)*256)
#             input_img = img[ybg:yend,xbg:xend]
#             #16bit转8bit，如果原始图片是8bit可以去掉
#             min_16bit = np.min(input_img)
#             max_16bit = np.max(input_img)
#             # input_img = np.array(np.rint(255*(input_img - min_16bit) / (max_16bit - min_16bit)), dtype=np.uint8)
#             input_img = (input_img - min_16bit) / (max_16bit - min_16bit)
#             #归一化
#             # input_img = input_img/255
#             #数据由（256，256）变为（1，256，256，1）
#             input_img = np.expand_dims(input_img,axis=0)
#             input_img = np.expand_dims(input_img, axis=3)
#             result = model.predict(input_img,1,verbose=0)
#             # img_pil = Image.fromarray(255 * result.squeeze())
#             # img_pil.save(os.path.join(img_out, basename+'_'+str(y)+'_'+str(x)+'.tif'))
#             result_zeros = np.zeros_like(input_img,dtype=np.uint8)
#             #找到大于0.8的像素点，抛弃物体像素小于30的个体，因为物体的长度实在不好求，师兄你可以尝试改一下min_size来进行微调
#             # result = result > 0.8
#             # denoise = skimage.morphology.remove_small_objects(result, min_size=29, connectivity=2)
#             result_zeros[result > 0.8] = 255
#             result_zeros = result_zeros.squeeze(3).squeeze(0)
#             num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(result_zeros, connectivity=8)
#             for st in range(stats.shape[0]):
#                 if st==0:
#                     if stats[st][2]!=256 or stats[st][3]!=256:
#                         print(stats[st])
#                 else:
#                     tempsv=stats[st][2:4]
#                     maxleg=np.max(tempsv)
#                     temparea=stats[st][4]
#                     if maxleg>=20 and stats[st][4]>=30:
#                         if isadd==0:
#                             num=num+1
#                             isadd=1
#                             break
#             img[y * 256:y * 256 + 256, x * 256:x * 256 + 256]=result_zeros
#
#     # img_pil = Image.fromarray(img.squeeze())
#     # img_pil.save(os.path.join(img_out, basename+'.tif'))
# print(num)
os.environ["CUDA_VISIBLE_DEVICES"] = "0" #字符串所对应环境的映像对象
config = tf.compat.v1.ConfigProto()
config.gpu_options.per_process_gpu_memory_fraction = 0.8  #占用50%显存
session = tf.compat.v1.Session(config=config)

img_dir = r'X:\liaomingwei\projectdata\194511\CH1_0.325_256um'
img_names = glob.glob(os.path.join(img_dir,'*.tif'))
img_out = r'X:\liaomingwei\projectdata\194511\result'
model = unet()
model.load_weights("unet_limo_20230721.hdf5")

f = open(os.path.join(img_out,'list.txt'), "w")
for name in img_names:
    img_neuron = {'signal': []}
    img = io.imread(name)
    img[img<50]=0
    out_image = np.zeros_like(img, dtype=np.uint8)
    basename = os.path.basename(name).split('.')[0].split('_')[1]
    print(basename)
    start_time=time.time()
    for y in range(img.shape[0]//256):
        for x in range(img.shape[1]//256):
            input_img = img[y*256:y*256+256,x*256:x*256+256]
            #16bit转8bit，如果原始图片是8bit可以去掉
            min_16bit = np.min(input_img)
            max_16bit = np.max(input_img)
            # input_img = np.array(np.rint(266*(input_img - min_16bit) / (max_16bit - min_16bit)), dtype=np.uint8)
            # #归一化
            # input_img = input_img/255
            if max_16bit!=0:
                input_img = (input_img - min_16bit) / (max_16bit - min_16bit)
            #数据由（256，256）变为（1，256，256，1）
            input_img = np.expand_dims(input_img,axis=0)
            input_img = np.expand_dims(input_img, axis=3)
            result = model.predict(input_img,1,verbose=0)

            result_zeros = np.zeros_like(input_img, dtype=np.uint8)
            # 找到大于0.8的像素点，抛弃物体像素小于30的个体，因为物体的长度实在不好求，师兄你可以尝试改一下min_size来进行微调
            # result = result > 0.8
            # denoise = skimage.morphology.remove_small_objects(result, min_size=29, connectivity=2)
            result_zeros[result > 0.8] = 255
            result_zeros = result_zeros.squeeze(3).squeeze(0)
            # img_pil = Image.fromarray(result_zeros.squeeze())
            # img_pil.save(os.path.join(img_out, str(basename)  +'_'+str(y)+'_'+str(x)+'.tif'))
            out_image[y * 256:y * 256 + 256, x * 256:x * 256 + 256] = result_zeros[0:256, 0:256]
            num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(result_zeros, connectivity=8)
            for st in range(stats.shape[0]):
                if st == 0:
                    if stats[st][2] != 256 or stats[st][3] != 256:
                        print(stats[st])
                else:
                    tempsv = stats[st][2:4]
                    maxleg = np.max(tempsv)
                    temparea = stats[st][4]
                    if maxleg >= 20 and stats[st][4] >= 30:
                        img_neuron['signal'].append(str(int(int(basename)/256))+'_'+str(y)+'_'+str(x))
            # print(y,x)
    end_time=time.time()
    run_time=end_time-start_time
    print("run time: {}s".format(run_time))
    img_pil = Image.fromarray(out_image.squeeze())
    img_pil.save(os.path.join(img_out, str(basename) + '.tif'))
    for line in img_neuron['signal']:
        f.write(line + '\n')
f.close()