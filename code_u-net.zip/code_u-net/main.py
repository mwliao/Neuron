from model import *
from data import *
import tensorflow as tf

os.environ["CUDA_VISIBLE_DEVICES"] = "0" #字符串所对应环境的映像对象
config = tf.ConfigProto()
config.gpu_options.per_process_gpu_memory_fraction = 0.5  #占用50%显存
session = tf.Session(config=config)

data_gen_args = dict(rotation_range=0.2,
                    width_shift_range=0.05,
                    height_shift_range=0.05,
                    shear_range=0.05,
                    zoom_range=0.05,
                    horizontal_flip=True,
                    fill_mode='nearest')
#train
myGene = trainGenerator(1,'data/18749/train','image','label',data_gen_args,save_to_dir = None,target_size=(1024,1024))

model = unet(input_size = (1024,1024,1))
model_checkpoint = ModelCheckpoint('unet_membrane.hdf5', monitor='loss',verbose=1, save_best_only=True) #保存模型
model.fit_generator(myGene,steps_per_epoch=300,epochs=1,callbacks=[model_checkpoint,TensorBoard(log_dir='./log')])

#test
# testGene = testGenerator("data/18749/test",target_size = (1024,1024))
# results = model.predict_generator(testGene,10,verbose=1)
# saveResult("data/18749/test",results)

#testGene = testGenerator("data/membrane/test")
testGene = testGenerator("X:/unet/8bitimage/signal")
model = unet()
model.load_weights("unet_limo_20230721.hdf5")
results = model.predict_generator(testGene,623,verbose=1)
saveResult("X:/unet/8bitimage/seg_signal",results)